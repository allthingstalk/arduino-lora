#ifndef KEYS_h
#define KEYS_h


uint8_t DEV_ADDR[4] = {};
uint8_t APPSKEY[16] = {};
uint8_t NWKSKEY[16] = {};


#endif
